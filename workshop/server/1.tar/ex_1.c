#include <stdio.h>
char b[100] = "### key 2 ###";

int main() {
  char *a = "### key 1 ###";
  return 0;
}
